package me.tiers;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.SoundCategory;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.io.File;
import java.io.IOException;
import java.util.*;

/** TierPlugin by ZcmTvv */
public class TierPlugin extends JavaPlugin implements Listener {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();
    private static final LegacyComponentSerializer SECTION = LegacyComponentSerializer.legacySection();
    private static final int[] DEFAULT_ELO = {100, 250, 450, 700, 1000, 1400, 1900, 2500, 3200, 4000};
    private static final int[] MENU_SLOTS = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25};
    private static final float GAP = 0.04f;
    private static final float CHAR_WIDTH = 0.15f;

    private final Map<UUID, Map<String, Integer>> data = new HashMap<>();
    private final Map<UUID, String> focus = new HashMap<>();
    private final Map<UUID, List<Display>> displays = new HashMap<>();
    private final Map<String, Long> killCooldown = new HashMap<>();
    private File dataFile;
    private boolean dirty = false;

    // ============================ lifecycle ============================

    @Override
    public void onEnable() {
        saveDefaultConfig();
        dataFile = new File(getDataFolder(), "data.yml");
        loadData();

        TierCommand cmd = new TierCommand(this);
        getCommand("tier").setExecutor(cmd);
        getCommand("tier").setTabCompleter(cmd);
        Bukkit.getPluginManager().registerEvents(this, this);

        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new TierExpansion(this).register();
            getLogger().info("PlaceholderAPI found - %tier_...% placeholders registered.");
        }

        Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (dirty) saveData();
        }, 600L, 600L);

        // displays FOLLOW the player (they are NOT passengers, so teleports/Multiverse/RTP keep working)
        int interval = Math.max(1, getConfig().getInt("follow-interval-ticks", 2));
        Bukkit.getScheduler().runTaskTimer(this, this::followTick, 20L, interval);

        for (Player p : Bukkit.getOnlinePlayers()) updateDisplay(p, false);
        getLogger().info("TierPlugin by ZcmTvv enabled.");
    }

    @Override
    public void onDisable() {
        for (List<Display> list : new ArrayList<>(displays.values())) {
            for (Display d : list) d.remove();
        }
        displays.clear();
        saveData();
    }

    public void reload() {
        reloadConfig();
        for (Player p : Bukkit.getOnlinePlayers()) updateDisplay(p, false);
    }

    // ============================ data ============================

    private void loadData() {
        data.clear();
        focus.clear();
        if (!dataFile.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(dataFile);

        ConfigurationSection players = yml.getConfigurationSection("players");
        if (players != null) {
            for (String uuidStr : players.getKeys(false)) {
                ConfigurationSection sec = players.getConfigurationSection(uuidStr);
                if (sec == null) continue;
                Map<String, Integer> elos = new LinkedHashMap<>();
                for (String mode : sec.getKeys(false)) {
                    Object o = sec.get(mode);
                    int elo = 0;
                    if (o instanceof Number) {
                        elo = ((Number) o).intValue();
                    } else if (o instanceof String) {
                        Tier t = Tier.parse((String) o); // old format ("LT4")
                        if (t != null) elo = threshold(t);
                    }
                    if (elo > 0) elos.put(mode.toLowerCase(Locale.ROOT), elo);
                }
                try {
                    if (!elos.isEmpty()) data.put(UUID.fromString(uuidStr), elos);
                } catch (IllegalArgumentException ignored) {
                }
            }
        }

        ConfigurationSection foc = yml.getConfigurationSection("focus");
        if (foc != null) {
            for (String uuidStr : foc.getKeys(false)) {
                try {
                    focus.put(UUID.fromString(uuidStr), foc.getString(uuidStr, "").toLowerCase(Locale.ROOT));
                } catch (IllegalArgumentException ignored) {
                }
            }
        }

        // players from older versions: focus their best mode
        for (Map.Entry<UUID, Map<String, Integer>> e : data.entrySet()) {
            if (focus.containsKey(e.getKey())) continue;
            String best = null;
            int bestRank = -2, bestElo = -1;
            for (Map.Entry<String, Integer> m : e.getValue().entrySet()) {
                Tier t = tierFor(m.getValue());
                int r = t == null ? -1 : t.ordinal();
                if (r > bestRank || (r == bestRank && m.getValue() > bestElo)) {
                    best = m.getKey();
                    bestRank = r;
                    bestElo = m.getValue();
                }
            }
            if (best != null) focus.put(e.getKey(), best);
        }
    }

    private void saveData() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Map.Entry<UUID, Map<String, Integer>> e : data.entrySet()) {
            for (Map.Entry<String, Integer> m : e.getValue().entrySet()) {
                yml.set("players." + e.getKey() + "." + m.getKey(), m.getValue());
            }
        }
        for (Map.Entry<UUID, String> e : focus.entrySet()) {
            yml.set("focus." + e.getKey(), e.getValue());
        }
        try {
            getDataFolder().mkdirs();
            yml.save(dataFile);
            dirty = false;
        } catch (IOException ex) {
            getLogger().severe("Could not save data.yml: " + ex.getMessage());
        }
    }

    // ============================ modes / focus ============================

    /** Enabled gamemodes, in config order. */
    public Set<String> getModes() {
        ConfigurationSection sec = getConfig().getConfigurationSection("modes");
        if (sec == null) return Collections.emptySet();
        List<String> enabled = getConfig().getStringList("enabled-modes");
        Set<String> out = new LinkedHashSet<>();
        for (String k : sec.getKeys(false)) {
            boolean on = enabled.isEmpty();
            for (String en : enabled) {
                if (en.equalsIgnoreCase(k)) on = true;
            }
            if (on) out.add(k);
        }
        return out;
    }

    /** The gamemode the player picked, or null if none / no longer enabled. */
    public String getFocus(UUID id) {
        String f = focus.get(id);
        return (f != null && getModes().contains(f)) ? f : null;
    }

    public void setFocus(UUID id, String mode) {
        focus.put(id, mode);
        dirty = true;
        Player p = Bukkit.getPlayer(id);
        if (p != null) updateDisplay(p, false);
    }

    /** Player picked a gamemode (command or menu). */
    public void chooseFocus(Player p, String mode) {
        setFocus(p.getUniqueId(), mode);
        int elo = getElo(p.getUniqueId(), mode);
        p.playSound(p.getLocation(), "ui.button.click", SoundCategory.MASTER, 1f, 1.2f);
        p.sendMessage(Component.text("\u2714 Now grinding ", NamedTextColor.GREEN)
                .append(modeNameComponent(mode))
                .append(Component.text(" \u2022 ", NamedTextColor.DARK_GRAY))
                .append(tierComponent(tierFor(elo)))
                .append(Component.text(" (" + elo + " Elo)", NamedTextColor.GRAY)));
    }

    public void openMenu(Player p) {
        TierMenu holder = new TierMenu();
        Inventory inv = Bukkit.createInventory(holder, 27, Component.text("Pick your gamemode", NamedTextColor.DARK_GRAY));
        holder.setInventory(inv);
        String current = getFocus(p.getUniqueId());

        int i = 0;
        for (String mode : getModes()) {
            if (i >= MENU_SLOTS.length) break;
            String itemName = getConfig().getString("modes." + mode + ".item", "");
            Material mat = itemName.isEmpty() ? null : Material.matchMaterial(itemName);
            if (mat == null || mat.isAir() || !mat.isItem()) mat = Material.PAPER;

            int elo = getElo(p.getUniqueId(), mode);
            ItemStack it = new ItemStack(mat);
            ItemMeta meta = it.getItemMeta();
            boolean selected = mode.equals(current);
            Component name = (selected ? Component.text("\u2605 ", NamedTextColor.GOLD) : Component.empty())
                    .append(modeNameComponent(mode));
            meta.displayName(name.decoration(TextDecoration.ITALIC, false));
            List<Component> lore = new ArrayList<>();
            lore.add(Component.text("Tier: ", NamedTextColor.GRAY).append(tierComponent(tierFor(elo)))
                    .decoration(TextDecoration.ITALIC, false));
            lore.add(Component.text("Elo: ", NamedTextColor.GRAY).append(Component.text(elo, NamedTextColor.WHITE))
                    .decoration(TextDecoration.ITALIC, false));
            lore.add(Component.empty());
            lore.add((selected
                    ? Component.text("\u2714 Currently selected", NamedTextColor.GREEN)
                    : Component.text("Click to focus on this gamemode", NamedTextColor.YELLOW))
                    .decoration(TextDecoration.ITALIC, false));
            meta.lore(lore);
            it.setItemMeta(meta);

            inv.setItem(MENU_SLOTS[i], it);
            holder.slots.put(MENU_SLOTS[i], mode);
            i++;
        }
        p.openInventory(inv);
    }

    // ============================ elo / tiers ============================

    public int threshold(Tier t) {
        return getConfig().getInt("tier-elo." + t.name(), DEFAULT_ELO[t.ordinal()]);
    }

    /** null = UNRANKED */
    public Tier tierFor(int elo) {
        Tier[] v = Tier.values();
        for (int i = v.length - 1; i >= 0; i--) {
            if (elo >= threshold(v[i])) return v[i];
        }
        return null;
    }

    public Tier nextTier(int elo) {
        Tier cur = tierFor(elo);
        return cur == null ? Tier.LT5 : cur.next();
    }

    public int progressPercent(int elo) {
        Tier cur = tierFor(elo);
        Tier next = nextTier(elo);
        if (next == null) return 100;
        int curT = cur == null ? 0 : threshold(cur);
        int nextT = threshold(next);
        if (nextT <= curT) return 100;
        double pct = (double) (elo - curT) / (nextT - curT);
        return (int) Math.round(Math.max(0, Math.min(1, pct)) * 100);
    }

    public int getElo(UUID id, String mode) {
        Map<String, Integer> m = data.get(id);
        return m == null ? 0 : m.getOrDefault(mode, 0);
    }

    public void setElo(UUID id, String mode, int newElo, boolean animate) {
        newElo = Math.max(0, newElo);
        Tier old = tierFor(getElo(id, mode));

        if (newElo == 0) {
            Map<String, Integer> m = data.get(id);
            if (m != null) {
                m.remove(mode);
                if (m.isEmpty()) data.remove(id);
            }
        } else {
            data.computeIfAbsent(id, k -> new LinkedHashMap<>()).put(mode, newElo);
            if (getFocus(id) == null) focus.put(id, mode); // first mode they earn elo in becomes their focus
        }
        dirty = true;

        Tier now = tierFor(newElo);
        if (now == old) return;

        boolean up = (now != null) && (old == null || now.ordinal() > old.ordinal());
        Player p = Bukkit.getPlayer(id);
        if (p != null) {
            // only the focused gamemode is shown above the head
            if (mode.equals(getFocus(id))) updateDisplay(p, up && animate);
            if (up && animate) {
                RankUpAnimation.play(this, p, mode, old, now);
            } else if (!up) {
                p.sendMessage(Component.text("\u25BC You dropped to ", NamedTextColor.RED)
                        .append(tierComponent(now))
                        .append(Component.text(" in ", NamedTextColor.RED))
                        .append(modeNameComponent(mode)));
            }
            if (up && animate) broadcastRankUp(p, mode, now);
        }
    }

    private void broadcastRankUp(Player p, String mode, Tier now) {
        Tier min = Tier.parse(getConfig().getString("broadcast-from", ""));
        if (min == null || now.ordinal() < min.ordinal()) return;
        Bukkit.broadcast(Component.text("\u2605 ", NamedTextColor.GOLD)
                .append(Component.text(p.getName(), NamedTextColor.WHITE))
                .append(Component.text(" reached ", NamedTextColor.GRAY))
                .append(tierComponent(now))
                .append(Component.text(" in ", NamedTextColor.GRAY))
                .append(modeNameComponent(mode))
                .append(Component.text("!", NamedTextColor.GRAY)));
    }

    // ============================ text helpers ============================

    public TextColor tierColor(Tier t) {
        String hex = t == null
                ? getConfig().getString("unranked-color", "#777777")
                : getConfig().getString("tier-colors." + t.name(), "#FFFFFF");
        TextColor c = TextColor.fromHexString(hex);
        return c != null ? c : NamedTextColor.WHITE;
    }

    private boolean isBold(Tier t) {
        return t != null && getConfig().getStringList("bold-tiers").contains(t.name());
    }

    /** Plain label: LT4 or UNRANKED */
    public String label(Tier t) {
        return t == null ? getConfig().getString("unranked-label", "UNRANKED") : t.name();
    }

    public Component tierComponent(Tier t) {
        Component c = Component.text(label(t), tierColor(t));
        if (isBold(t)) c = c.decorate(TextDecoration.BOLD);
        return c;
    }

    /** Section-sign hex format, e.g. §x§5§5§F§F§5§5LT4 */
    public String legacyColored(Tier t) {
        String hex = tierColor(t).asHexString().substring(1);
        StringBuilder sb = new StringBuilder("\u00A7x");
        for (char ch : hex.toCharArray()) sb.append('\u00A7').append(ch);
        if (isBold(t)) sb.append("\u00A7l");
        return sb.append(label(t)).toString();
    }

    /** &#RRGGBB format, e.g. &#55FF55LT4 */
    public String hexColored(Tier t) {
        String s = "&" + tierColor(t).asHexString().toUpperCase(Locale.ROOT);
        if (isBold(t)) s += "&l";
        return s + label(t);
    }

    public String coloredIcon(String mode) {
        String pack = getConfig().getString("modes." + mode + ".pack-icon", "");
        if (getConfig().getBoolean("use-pack-icons", false) && !pack.isEmpty()) {
            return "\u00A7f" + pack; // white so the resource-pack texture keeps its own colors
        }
        String col = getConfig().getString("modes." + mode + ".color", "&f").replace('&', '\u00A7');
        return col + getConfig().getString("modes." + mode + ".icon", "?");
    }

    public String modeName(String mode) {
        String n = getConfig().getString("modes." + mode + ".name");
        if (n != null) return n;
        return mode.isEmpty() ? mode : Character.toUpperCase(mode.charAt(0)) + mode.substring(1);
    }

    public Component modeNameComponent(String mode) {
        return LEGACY.deserialize(getConfig().getString("modes." + mode + ".color", "&f") + modeName(mode));
    }

    // ============================ /tier progress ============================

    public void sendProgress(CommandSender to, UUID id, String playerName) {
        to.sendMessage(Component.text("\u2501\u2501\u2501 ", NamedTextColor.DARK_GRAY)
                .append(Component.text(playerName + "'s Tiers", NamedTextColor.GOLD, TextDecoration.BOLD))
                .append(Component.text(" \u2501\u2501\u2501", NamedTextColor.DARK_GRAY)));

        String foc = getFocus(id);
        Set<String> show = new LinkedHashSet<>();
        for (String m : getModes()) {
            if (getElo(id, m) > 0 || m.equals(foc)) show.add(m);
        }

        if (show.isEmpty()) {
            to.sendMessage(Component.text("No gamemode picked yet. Use /tier mode to choose one!", NamedTextColor.YELLOW));
            return;
        }

        for (String mode : show) {
            int elo = getElo(id, mode);
            Tier cur = tierFor(elo);
            Tier next = nextTier(elo);

            Component head = (mode.equals(foc) ? Component.text("\u2605 ", NamedTextColor.GOLD) : Component.text("  "))
                    .append(modeNameComponent(mode))
                    .append(Component.text("  ", NamedTextColor.GRAY))
                    .append(tierComponent(cur))
                    .append(Component.text("  |  ", NamedTextColor.DARK_GRAY))
                    .append(Component.text(elo + " Elo", NamedTextColor.WHITE));
            to.sendMessage(head);

            if (next == null) {
                to.sendMessage(Component.text("    MAX TIER REACHED", NamedTextColor.GOLD, TextDecoration.BOLD));
            } else {
                int pct = progressPercent(elo);
                int filled = Math.round(pct / 5f);
                int nextT = threshold(next);
                to.sendMessage(Component.text("    ")
                        .append(Component.text("\u2588".repeat(filled), tierColor(next)))
                        .append(Component.text("\u2588".repeat(20 - filled), NamedTextColor.DARK_GRAY))
                        .append(Component.text(" " + pct + "%", NamedTextColor.WHITE))
                        .append(Component.text("   " + elo + "/" + nextT + " \u2192 ", NamedTextColor.GRAY))
                        .append(tierComponent(next))
                        .append(Component.text("  (" + (nextT - elo) + " to go)", NamedTextColor.DARK_GRAY)));
            }
        }
        to.sendMessage(Component.text("Kill players in your focus gamemode to earn Elo. Change it with /tier mode", NamedTextColor.GRAY));
    }

    // ============================ display ============================

    private static final double HEAD_HEIGHT = 1.8;
    private static final double MAX_FOLLOW_DIST_SQ = 32.0 * 32.0;

    public void removeDisplay(Player p) {
        List<Display> list = displays.remove(p.getUniqueId());
        if (list == null) return;
        for (Display d : list) d.remove();
    }

    private boolean shouldHide(Player p) {
        return p.isDead() || p.isInvisible() || p.getGameMode() == GameMode.SPECTATOR;
    }

    /** Keeps every display glued above its player. Rebuilds them if anything went wrong. */
    private void followTick() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            UUID id = p.getUniqueId();
            if (shouldHide(p)) {
                if (displays.containsKey(id)) removeDisplay(p);
                continue;
            }
            List<Display> list = displays.get(id);
            if (list == null) {
                updateDisplay(p, false);
                continue;
            }
            if (list.isEmpty()) continue;

            Location target = p.getLocation().add(0, HEAD_HEIGHT, 0);
            target.setYaw(0f);
            target.setPitch(0f);

            boolean rebuild = false;
            for (Display d : list) {
                if (!d.isValid() || !d.getWorld().equals(p.getWorld())
                        || d.getLocation().distanceSquared(target) > MAX_FOLLOW_DIST_SQ) {
                    rebuild = true;
                    break;
                }
            }
            if (rebuild) {
                updateDisplay(p, false);
                continue;
            }
            for (Display d : list) d.teleport(target);
        }
    }

    private Transformation transform(float x, float y, float scale) {
        return new Transformation(new Vector3f(x, y, 0f), new AxisAngle4f(),
                new Vector3f(scale, scale, scale), new AxisAngle4f());
    }

    private void popIn(Display d, Transformation fin) {
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (d.isValid()) {
                d.setInterpolationDelay(0);
                d.setInterpolationDuration(15);
                d.setTransformation(fin);
            }
        }, 2L);
    }

    /**
     * Above the head: the FOCUS gamemode's icon + tier.
     * No focus, or unranked (with unranked-show-icon: false) = only the UNRANKED text.
     */
    public void updateDisplay(Player p, boolean animated) {
        removeDisplay(p);
        UUID id = p.getUniqueId();
        List<Display> out = new ArrayList<>();
        displays.put(id, out);
        if (shouldHide(p)) return;

        String mode = getFocus(id);
        Tier tier = mode == null ? null : tierFor(getElo(id, mode));
        if (tier == null && !getConfig().getBoolean("show-unranked", true)) return;

        boolean plain = mode == null || (tier == null && !getConfig().getBoolean("unranked-show-icon", false));

        Component text = tierComponent(tier);
        int chars = tier == null ? label(null).length() : 3;
        float textWidth = CHAR_WIDTH * chars;

        float y = (float) getConfig().getDouble("y-offset", 0.8);
        if (p.getScoreboard().getObjective(DisplaySlot.BELOW_NAME) != null
                || Bukkit.getScoreboardManager().getMainScoreboard().getObjective(DisplaySlot.BELOW_NAME) != null) {
            y += (float) getConfig().getDouble("below-name-extra", 0.3);
        }
        final float yy = y;
        final float start = animated ? 0.01f : 1f;
        final int tpDur = Math.min(59, Math.max(1, getConfig().getInt("follow-interval-ticks", 2) + 1));

        Location base = p.getLocation().add(0, HEAD_HEIGHT, 0);
        base.setYaw(0f);
        base.setPitch(0f);

        Material mat = null;
        if (!plain) {
            String itemName = getConfig().getString("modes." + mode + ".item", "");
            mat = itemName.isEmpty() ? null : Material.matchMaterial(itemName);
            if (mat != null && (mat.isAir() || !mat.isItem())) mat = null;
        }

        if (plain) {
            spawnText(p, base, text, 0f, yy, start, animated, tpDur, out);
        } else if (mat != null) {
            float itemScale = (float) getConfig().getDouble("item-scale", 0.3);
            float itemY = yy + (float) getConfig().getDouble("item-y-adjust", 0.12);
            float total = itemScale + GAP + textWidth;
            float itemX = -total / 2f + itemScale / 2f;
            float textX = -total / 2f + itemScale + GAP + textWidth / 2f;

            final Material fm = mat;
            ItemDisplay item = p.getWorld().spawn(base, ItemDisplay.class, d -> {
                d.setItemStack(new ItemStack(fm));
                d.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.GUI);
                d.setBillboard(Display.Billboard.CENTER);
                d.setPersistent(false);
                d.setTeleportDuration(tpDur);
                d.setTransformation(transform(itemX, itemY, itemScale * start));
            });
            p.hideEntity(this, item);
            out.add(item);
            if (animated) popIn(item, transform(itemX, itemY, itemScale));

            spawnText(p, base, text, textX, yy, start, animated, tpDur, out);
        } else {
            Component full = SECTION.deserialize(coloredIcon(mode) + " ").append(text);
            spawnText(p, base, full, 0f, yy, start, animated, tpDur, out);
        }
    }

    private void spawnText(Player p, Location base, Component text, float x, float y, float start,
                           boolean animated, int tpDur, List<Display> out) {
        TextDisplay display = p.getWorld().spawn(base, TextDisplay.class, d -> {
            d.text(text);
            d.setBillboard(Display.Billboard.CENTER);
            d.setBackgroundColor(Color.fromARGB(0, 0, 0, 0));
            d.setShadowed(true);
            d.setPersistent(false);
            d.setTeleportDuration(tpDur);
            d.setTransformation(transform(x, y, start));
        });
        p.hideEntity(this, display); // don't show it to the player themselves
        out.add(display);
        if (animated) popIn(display, transform(x, y, 1f));
    }

    // ============================ kills ============================

    /** Gamemode mapped to this world, or null. */
    private String modeForWorld(String world) {
        for (String m : getModes()) {
            for (String w : getConfig().getStringList("modes." + m + ".worlds")) {
                if (w.equalsIgnoreCase(world)) return m;
            }
        }
        return null;
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        Player killer = victim.getKiller();
        if (killer == null || killer.equals(victim)) return;

        String mode = modeForWorld(victim.getWorld().getName());
        if (mode == null) mode = getFocus(killer.getUniqueId());
        if (mode == null) {
            killer.sendActionBar(Component.text("Pick a gamemode with /tier mode to earn Elo!", NamedTextColor.YELLOW));
            return;
        }

        long now = System.currentTimeMillis();
        long cd = getConfig().getLong("kill-tracking.same-victim-cooldown-seconds", 120) * 1000L;
        String key = killer.getUniqueId() + ":" + victim.getUniqueId();
        Long last = killCooldown.get(key);
        if (last != null && now - last < cd) {
            killer.sendActionBar(Component.text("No Elo - you killed this player too recently", NamedTextColor.RED));
            return;
        }
        if (killCooldown.size() > 2000) killCooldown.clear();
        killCooldown.put(key, now);

        int gain = getConfig().getInt("kill-tracking.kill-gain", 25);
        int bonusPer = getConfig().getInt("kill-tracking.higher-tier-bonus", 5);
        int loss = getConfig().getInt("kill-tracking.death-loss", 10);

        int killerElo = getElo(killer.getUniqueId(), mode);
        int victimElo = getElo(victim.getUniqueId(), mode);
        Tier kt = tierFor(killerElo);
        Tier vt = tierFor(victimElo);
        int diff = (vt == null ? -1 : vt.ordinal()) - (kt == null ? -1 : kt.ordinal());
        if (diff > 0) gain += diff * bonusPer;

        setElo(killer.getUniqueId(), mode, killerElo + gain, true);
        if (loss > 0 && victimElo > 0) {
            setElo(victim.getUniqueId(), mode, victimElo - loss, true);
        }

        if (getConfig().getBoolean("kill-tracking.actionbar", true)) {
            int elo = killerElo + gain;
            Tier next = nextTier(elo);
            Component bar = Component.text("+" + gain + " Elo", NamedTextColor.GREEN, TextDecoration.BOLD)
                    .append(Component.text("  " + modeName(mode), NamedTextColor.GRAY));
            if (next != null) {
                bar = bar.append(Component.text("  " + elo + "/" + threshold(next) + " \u2192 ", NamedTextColor.GRAY))
                        .append(tierComponent(next));
            }
            killer.sendActionBar(bar);
        }
    }

    // ============================ events ============================

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(this, () -> updateDisplay(p, false), 5L);

        if (getConfig().getBoolean("prompt-on-join", true)) {
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (p.isOnline() && getFocus(p.getUniqueId()) == null) {
                    p.sendMessage(Component.text("Pick the gamemode you want to rank in: ", NamedTextColor.YELLOW)
                            .append(Component.text("[CLICK HERE]", NamedTextColor.GREEN, TextDecoration.BOLD)
                                    .clickEvent(ClickEvent.runCommand("/tier mode"))));
                }
            }, 40L);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        removeDisplay(e.getPlayer());
    }

    // Displays are not passengers any more, so teleports always work.
    // For long / cross-world teleports we just drop the old display; followTick() rebuilds it at the new spot.
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) {
        Location from = e.getFrom();
        Location to = e.getTo();
        if (to == null || to.getWorld() == null || !to.getWorld().equals(from.getWorld())
                || from.distanceSquared(to) > MAX_FOLLOW_DIST_SQ) {
            removeDisplay(e.getPlayer());
        }
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        removeDisplay(e.getPlayer());
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        removeDisplay(e.getPlayer());
    }

    @EventHandler
    public void onMenuClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof TierMenu menu)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;
        String mode = menu.slots.get(e.getSlot());
        if (mode == null) return;
        Player p = (Player) e.getWhoClicked();
        chooseFocus(p, mode);
        p.closeInventory();
    }

    @EventHandler
    public void onMenuDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof TierMenu) e.setCancelled(true);
    }
}
