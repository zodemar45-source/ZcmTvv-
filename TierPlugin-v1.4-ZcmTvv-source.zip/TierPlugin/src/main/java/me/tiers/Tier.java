package me.tiers;

/** Ordered lowest -> highest. ordinal() is the rank. TierPlugin by ZcmTvv */
public enum Tier {
    LT5, HT5, LT4, HT4, LT3, HT3, LT2, HT2, LT1, HT1;

    public static Tier parse(String s) {
        try {
            return Tier.valueOf(s.toUpperCase());
        } catch (IllegalArgumentException | NullPointerException e) {
            return null;
        }
    }

    public Tier next() {
        return ordinal() + 1 < values().length ? values()[ordinal() + 1] : null;
    }
}
