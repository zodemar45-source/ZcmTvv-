package me.tiers;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.HashMap;
import java.util.Map;

/** Holder for the gamemode picker menu. TierPlugin by ZcmTvv */
public class TierMenu implements InventoryHolder {

    public final Map<Integer, String> slots = new HashMap<>();
    private Inventory inventory;

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
