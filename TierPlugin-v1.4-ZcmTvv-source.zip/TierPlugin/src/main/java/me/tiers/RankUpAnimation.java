package me.tiers;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.SoundCategory;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.scheduler.BukkitRunnable;

import java.time.Duration;

/** Rank-up animation: color-cycling title + particle spiral, then a big reveal. By ZcmTvv */
public final class RankUpAnimation {

    private static final int BUILDUP_TICKS = 32;
    private static Particle dustParticle;

    private RankUpAnimation() {
    }

    private static Particle dust() {
        if (dustParticle == null) {
            try {
                dustParticle = Particle.valueOf("DUST");
            } catch (IllegalArgumentException e) {
                dustParticle = Particle.valueOf("REDSTONE");
            }
        }
        return dustParticle;
    }

    private static void sound(Player p, String key, float vol, float pitch) {
        p.playSound(p.getLocation(), key, SoundCategory.MASTER, vol, pitch);
    }

    private static Color toColor(TextColor c) {
        return Color.fromRGB(c.red(), c.green(), c.blue());
    }

    public static void play(TierPlugin plugin, Player p, String modeKey, Tier from, Tier to) {
        final TextColor color = plugin.tierColor(to);
        final Tier[] all = Tier.values();

        new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                if (!p.isOnline()) {
                    cancel();
                    return;
                }
                Location base = p.getLocation();

                if (t < BUILDUP_TICKS) {
                    // rising double spiral
                    double angle = t * 0.55;
                    double y = t * 0.065;
                    double radius = 1.1 - t * 0.012;
                    for (int i = 0; i < 2; i++) {
                        double a = angle + i * Math.PI;
                        Location l = base.clone().add(Math.cos(a) * radius, y, Math.sin(a) * radius);
                        p.getWorld().spawnParticle(dust(), l, 1, 0, 0, 0, 0,
                                new Particle.DustOptions(toColor(color), 1.4f));
                        p.getWorld().spawnParticle(Particle.END_ROD, l, 1, 0, 0, 0, 0);
                    }
                    // title cycles through every tier color
                    if (t % 3 == 0) {
                        Tier cyc = all[(t / 3) % all.length];
                        Title title = Title.title(
                                Component.text("RANK UP", plugin.tierColor(cyc), TextDecoration.BOLD),
                                Component.text("???", NamedTextColor.GRAY).decorate(TextDecoration.OBFUSCATED),
                                Title.Times.times(Duration.ZERO, Duration.ofMillis(400), Duration.ZERO));
                        p.showTitle(title);
                    }
                    if (t % 4 == 0) {
                        sound(p, "block.note_block.chime", 0.8f, 0.5f + (t / (float) BUILDUP_TICKS) * 1.5f);
                    }
                } else if (t == BUILDUP_TICKS) {
                    // THE REVEAL
                    Component newLabel = plugin.tierComponent(to).decorate(TextDecoration.BOLD);
                    Component oldLabel = plugin.tierComponent(from);
                    Component sub = oldLabel
                            .append(Component.text("  \u279C  ", NamedTextColor.DARK_GRAY))
                            .append(plugin.tierComponent(to))
                            .append(Component.text("   \u2022   ", NamedTextColor.DARK_GRAY))
                            .append(plugin.modeNameComponent(modeKey));
                    p.showTitle(Title.title(newLabel, sub,
                            Title.Times.times(Duration.ZERO, Duration.ofMillis(3200), Duration.ofMillis(1000))));

                    sound(p, "ui.toast.challenge_complete", 1f, 1f);
                    sound(p, "entity.player.levelup", 1f, 1.2f);
                    sound(p, "entity.firework_rocket.twinkle", 1f, 1f);
                    if (to == Tier.HT1 || to == Tier.LT1) {
                        sound(p, "entity.ender_dragon.growl", 0.6f, 1.4f);
                    }

                    Location up = base.clone().add(0, 1, 0);
                    p.getWorld().spawnParticle(Particle.END_ROD, up, 80, 0.4, 0.8, 0.4, 0.2);
                    p.getWorld().spawnParticle(dust(), up, 60, 0.6, 0.9, 0.6, 0,
                            new Particle.DustOptions(toColor(color), 1.6f));

                    // fireworks in the tier color
                    for (int i = 0; i < 2; i++) {
                        Firework fw = p.getWorld().spawn(base.clone().add(0, 0.5, 0), Firework.class);
                        FireworkMeta meta = fw.getFireworkMeta();
                        meta.addEffect(FireworkEffect.builder()
                                .with(i == 0 ? FireworkEffect.Type.BALL_LARGE : FireworkEffect.Type.STAR)
                                .withColor(toColor(color))
                                .withFade(Color.WHITE)
                                .withTrail()
                                .withFlicker()
                                .build());
                        fw.setFireworkMeta(meta);
                        fw.detonate();
                    }
                } else if (t < BUILDUP_TICKS + 22) {
                    // expanding ring after the reveal
                    double r = (t - BUILDUP_TICKS) * 0.22;
                    for (int i = 0; i < 24; i++) {
                        double a = i * (Math.PI * 2 / 24);
                        Location l = base.clone().add(Math.cos(a) * r, 0.15, Math.sin(a) * r);
                        p.getWorld().spawnParticle(dust(), l, 1, 0, 0, 0, 0,
                                new Particle.DustOptions(toColor(color), 1.2f));
                    }
                } else {
                    cancel();
                    return;
                }
                t++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }
}
