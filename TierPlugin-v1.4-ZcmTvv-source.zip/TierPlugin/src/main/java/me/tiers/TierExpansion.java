package me.tiers;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;

import java.util.Locale;
import java.util.UUID;

/**
 * PlaceholderAPI expansion, identifier: tier   (by ZcmTvv)
 *
 * Focus gamemode (the one the player picked):
 *   %tier_tier%          LT4 / UNRANKED
 *   %tier_tier_colored%  colored with section-sign hex (works in most chat/tab plugins)
 *   %tier_tier_hex%      colored with &#RRGGBB format
 *   %tier_mode%          Sword / None
 *   %tier_icon%          colored text icon of the mode
 *   %tier_display%       icon + colored tier (just UNRANKED when unranked)
 *   %tier_elo%           elo in the focus mode
 *   %tier_next%          next tier name (MAX if none)
 *   %tier_next_elo%      elo needed for the next tier
 *   %tier_progress%      0-100 progress to next tier
 * Specific gamemode (replace <mode> with sword, crystal, ...):
 *   %tier_<mode>%  %tier_<mode>_colored%  %tier_<mode>_hex%  %tier_<mode>_elo%
 */
public class TierExpansion extends PlaceholderExpansion {

    private final TierPlugin plugin;

    public TierExpansion(TierPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getIdentifier() {
        return "tier";
    }

    @Override
    public String getAuthor() {
        return "ZcmTvv";
    }

    @Override
    public String getVersion() {
        return plugin.getDescription().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer player, String params) {
        if (player == null) return "";
        UUID id = player.getUniqueId();
        String p = params.toLowerCase(Locale.ROOT);

        String focus = plugin.getFocus(id);
        int elo = focus == null ? 0 : plugin.getElo(id, focus);
        Tier tier = plugin.tierFor(elo);

        switch (p) {
            case "tier":
                return plugin.label(tier);
            case "tier_colored":
                return plugin.legacyColored(tier);
            case "tier_hex":
                return plugin.hexColored(tier);
            case "mode":
                return focus == null ? "None" : plugin.modeName(focus);
            case "icon":
                return focus == null ? "" : plugin.coloredIcon(focus);
            case "display":
                if (focus == null || tier == null) return plugin.legacyColored(tier);
                return plugin.coloredIcon(focus) + " " + plugin.legacyColored(tier);
            case "elo":
                return String.valueOf(elo);
            case "next": {
                Tier next = plugin.nextTier(elo);
                return next == null ? "MAX" : next.name();
            }
            case "next_elo": {
                Tier next = plugin.nextTier(elo);
                return next == null ? "0" : String.valueOf(plugin.threshold(next));
            }
            case "progress":
                return String.valueOf(plugin.progressPercent(elo));
            default:
                break;
        }

        // per-gamemode placeholders: <mode>, <mode>_colored, <mode>_hex, <mode>_elo
        String[] parts = p.split("_", 2);
        if (plugin.getModes().contains(parts[0])) {
            int mElo = plugin.getElo(id, parts[0]);
            Tier mTier = plugin.tierFor(mElo);
            if (parts.length == 1) return plugin.label(mTier);
            switch (parts[1]) {
                case "colored":
                    return plugin.legacyColored(mTier);
                case "hex":
                    return plugin.hexColored(mTier);
                case "elo":
                    return String.valueOf(mElo);
                default:
                    return null;
            }
        }
        return null;
    }
}
