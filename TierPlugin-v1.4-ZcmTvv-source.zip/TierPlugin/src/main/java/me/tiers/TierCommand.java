package me.tiers;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/** TierPlugin by ZcmTvv */
public class TierCommand implements CommandExecutor, TabCompleter {

    private final TierPlugin plugin;

    public TierCommand(TierPlugin plugin) {
        this.plugin = plugin;
    }

    private void usage(CommandSender s) {
        s.sendMessage("§6Tier commands:");
        s.sendMessage("§e/tier §7- your progress");
        s.sendMessage("§e/tier mode [gamemode] §7- pick the gamemode you grind");
        s.sendMessage("§e/tier <player> §7- someone's progress");
        if (s.hasPermission("tier.admin")) {
            s.sendMessage("§e/tier <player> <gamemode> <tier> §7- set tier (LT5..HT1)");
            s.sendMessage("§e/tier <player> <gamemode> elo <amount> §7- set elo");
            s.sendMessage("§e/tier <player> <gamemode> add <amount> §7- add/remove elo");
            s.sendMessage("§e/tier <player> <gamemode> remove §7- reset to UNRANKED");
            s.sendMessage("§e/tier reload");
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        // /tier -> own progress
        if (args.length == 0) {
            if (!(sender instanceof Player p)) {
                usage(sender);
                return true;
            }
            plugin.sendProgress(p, p.getUniqueId(), p.getName());
            return true;
        }

        // /tier mode [gamemode]
        if (args[0].equalsIgnoreCase("mode") || args[0].equalsIgnoreCase("focus")) {
            if (!(sender instanceof Player pl)) {
                sender.sendMessage("Players only.");
                return true;
            }
            if (!pl.hasPermission("tier.use")) {
                pl.sendMessage("§cYou don't have permission.");
                return true;
            }
            if (args.length == 1) {
                plugin.openMenu(pl);
                return true;
            }
            String m = args[1].toLowerCase(Locale.ROOT);
            if (!plugin.getModes().contains(m)) {
                pl.sendMessage("§cUnknown gamemode. Available: §f" + String.join(", ", plugin.getModes()));
                return true;
            }
            plugin.chooseFocus(pl, m);
            return true;
        }

        if (args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("tier.admin")) {
                sender.sendMessage("§cYou don't have permission.");
                return true;
            }
            plugin.reload();
            sender.sendMessage("§aTierPlugin reloaded.");
            return true;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        if (!target.isOnline() && !target.hasPlayedBefore()) {
            sender.sendMessage("§cPlayer not found.");
            return true;
        }
        String name = target.getName() != null ? target.getName() : args[0];

        if (args.length == 1) {
            if (!sender.hasPermission("tier.use")) {
                sender.sendMessage("§cYou don't have permission.");
                return true;
            }
            plugin.sendProgress(sender, target.getUniqueId(), name);
            return true;
        }

        // admin only below
        if (!sender.hasPermission("tier.admin")) {
            sender.sendMessage("§cYou don't have permission.");
            return true;
        }

        String mode = args[1].toLowerCase(Locale.ROOT);
        if (!plugin.getModes().contains(mode)) {
            sender.sendMessage("§cUnknown gamemode. Available: §f" + String.join(", ", plugin.getModes()));
            return true;
        }
        if (args.length < 3) {
            usage(sender);
            return true;
        }

        UUID id = target.getUniqueId();
        String action = args[2].toLowerCase(Locale.ROOT);
        boolean switchFocus = plugin.getConfig().getBoolean("admin-set-switches-focus", true);

        switch (action) {
            case "remove", "reset" -> {
                plugin.setElo(id, mode, 0, false);
                sender.sendMessage("§aReset §e" + name + "§a's §f" + mode + " §ato UNRANKED.");
            }
            case "elo", "add" -> {
                if (args.length < 4) {
                    sender.sendMessage("§cUsage: /tier " + name + " " + mode + " " + action + " <amount>");
                    return true;
                }
                int amount;
                try {
                    amount = Integer.parseInt(args[3]);
                } catch (NumberFormatException ex) {
                    sender.sendMessage("§cThat's not a number.");
                    return true;
                }
                int newElo = action.equals("elo") ? amount : plugin.getElo(id, mode) + amount;
                if (switchFocus) plugin.setFocus(id, mode);
                plugin.setElo(id, mode, newElo, true);
                sender.sendMessage("§e" + name + "§a's §f" + mode + " §aElo is now §6" + Math.max(0, newElo) + "§a.");
            }
            default -> {
                Tier tier = Tier.parse(args[2]);
                if (tier == null) {
                    sender.sendMessage("§cInvalid tier. Use: LT5 HT5 LT4 HT4 LT3 HT3 LT2 HT2 LT1 HT1");
                    return true;
                }
                if (switchFocus) plugin.setFocus(id, mode);
                plugin.setElo(id, mode, plugin.threshold(tier), true);
                sender.sendMessage("§aSet §e" + name + "§a's §f" + mode + " §atier to §6" + tier.name()
                        + " §7(" + plugin.threshold(tier) + " Elo)§a.");
            }
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        boolean admin = sender.hasPermission("tier.admin");
        if (args.length == 1) {
            for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
            out.add("mode");
            if (admin) out.add("reload");
        } else if (args[0].equalsIgnoreCase("mode") || args[0].equalsIgnoreCase("focus")) {
            if (args.length == 2) out.addAll(plugin.getModes());
        } else if (!admin) {
            return out;
        } else if (args.length == 2) {
            out.addAll(plugin.getModes());
        } else if (args.length == 3) {
            for (Tier t : Tier.values()) out.add(t.name());
            out.add("elo");
            out.add("add");
            out.add("remove");
        }
        String last = args[args.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(s -> !s.toLowerCase(Locale.ROOT).startsWith(last));
        return out;
    }
}
