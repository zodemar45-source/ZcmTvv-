TierPlugin by ZcmTvv

BUILD (needs JDK 17+ and Maven):
    mvn package
The jar is created at target/TierPlugin-1.4.0.jar -> put it in your server's plugins folder.

NO JAVA INSTALLED? Use GitHub:
1. Make a free GitHub repository and upload everything in this folder (including the .github folder).
2. Open the "Actions" tab -> "Build TierPlugin" -> wait for the green check.
3. Open the finished run -> download "TierPlugin-jar" under Artifacts.
